num1 = 4
num2 = 6
result = num1 + num2
print(result)